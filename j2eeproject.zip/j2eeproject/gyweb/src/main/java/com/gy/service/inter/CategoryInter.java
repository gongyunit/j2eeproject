// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.gy.service.inter;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.gy.model.CateInfoRelation;
import com.gy.model.Category;

//处理分类以及分类和资讯关系的服务层接口类
public interface CategoryInter {
	
	//调用数据库访问层的类，插入一个分类
	int insert(Category category);
    
	//调用数据库访问层的类，查询所有分类，
	List<Category> getCategoryns();
    
	//调用数据库访问层的类，根据id查询分类
	Category selectByID(Long id);
    
	//调用数据库访问层的类，更新分类
	int update( Category category);
    
	//调用数据库访问层的类，删除一个分类
	int delete( Long id);
    
	//调用数据库访问层的类，批量插入分类和资讯的关系
	int insertRelations(List<CateInfoRelation> relationList);
	
	//调用数据库访问层的类，根据分类id删除分类资讯关系
	int deleteRelationByCateid(Long cateid);
    
	//调用数据库访问层的类，根据分类id，查询该分类下的分类资讯关系集合
	List<CateInfoRelation> getRelationsByCateid(Long cateid);
    
	//调用数据库访问层的类，查询所有关系
	List<CateInfoRelation> getRelations();

    
}
