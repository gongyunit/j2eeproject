// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.gy.model;

import java.util.LinkedList;
import java.util.List;

//基于分类集合以及资讯集合封装的实体类
public class CateInfoVO {
	
	private List<Category> categoryList = new LinkedList<Category>();
	private List<Information> infoList = new LinkedList<Information>();
	
	public List<Category> getCategoryList() {
		return categoryList;
	}
	public void setCategoryList(List<Category> categoryList) {
		this.categoryList = categoryList;
	}
	public List<Information> getInfoList() {
		return infoList;
	}
	public void setInfoList(List<Information> infoList) {
		this.infoList = infoList;
	}

}
