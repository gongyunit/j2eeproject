// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.gy.dao.cache;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.springframework.data.redis.core.HashOperations;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.ZSetOperations;
import com.gy.dao.cache.inter.ICategoryCacheDao;
import com.gy.model.CateInfoRelation;
import com.gy.model.Category;
import com.gy.util.obj2json.CacheUtil;
//处理分类缓存的数据访问层代码
public class CategoryCacheDaoImpl implements ICategoryCacheDao{

	private RedisTemplate<String,Object> redisTemplate;  
	private final static String cateKeyStart = "cateRoot:category";
	private final static String caInReKeyStart = "caInReRoot:caInRe";

	//将spring提供的redistemplate设置到本类中
    public void setRedisTemplate(RedisTemplate<String, Object> redisTemplate)  
    {  
        this.redisTemplate = redisTemplate;  
    }

    //从缓存中，批量插入分类
    @Override
	public void insertList(List<Category> categoryList) {
    	for(Category category:categoryList){
    		Map<String, String> catemap =CacheUtil.convertObject2Map(category);
    		HashOperations<String, Object, Object>  catehash = redisTemplate.opsForHash();
    		catehash.putAll(cateKeyStart+category.getId(), catemap);
    	}
	}  

    //从缓存中，通过模糊匹配的方式，批量删除所有的分类
	@Override
	public void deleteAll() {
		redisTemplate.delete(redisTemplate.keys(cateKeyStart+"*"));
	}
	
	//从缓存中，获取所有的分类
	@Override
	public List<Category> getCategorys() {
		List<Category> categoryList = new ArrayList<Category>();
		
		HashOperations<String, Object, Object>  catehash = redisTemplate.opsForHash();
		Set<String> cateKeys = redisTemplate.keys(cateKeyStart+"*");
		
		for(String key:cateKeys){
			Map<Object, Object> catemap = catehash.entries(key);
			Category category = CacheUtil.convertMap2Object(catemap, Category.class);
			categoryList.add(category);
		}
		return categoryList;
	}

	//从缓存中，批量插入分类和资讯的关系
	@Override
	public void insertRelations(List<CateInfoRelation> relationList) {
		for(CateInfoRelation cateInfoRelation:relationList){
    		 ZSetOperations<String, Object> zset = redisTemplate.opsForZSet();
    	     zset.add(caInReKeyStart+cateInfoRelation.getCateid(), cateInfoRelation.getInfoid()+"", cateInfoRelation.getCreateTime().getTime());
    	}
		
	}

	//从缓存中，删除所有的分类和资讯关系
	@Override
	public void deleteAllRelations() {
		redisTemplate.delete(redisTemplate.keys(caInReKeyStart+"*"));
	}

	//根据分类id，查询该分类下的所有资讯id的集合
	@Override
	public Set<Object> getRelationsByCateid(Long cateid) {
		ZSetOperations<String, Object> zset = redisTemplate.opsForZSet();
		Set<Object> infoids = zset.reverseRange(caInReKeyStart+cateid, 0, -1);
		return infoids;
	}
	
	
}
