// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.gy.model;

import java.util.LinkedList;
import java.util.List;

//基于资讯的集合封装的实体类
public class InformationVO {

	private List<Information> infoList = new LinkedList<Information>();

	public List<Information> getInfoList() {
		return infoList;
	}

	public void setInfoList(List<Information> infoList) {
		this.infoList = infoList;
	}
	
	
}
