// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.gy.controller;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import com.gy.model.CateInfoVO;
import com.gy.service.inter.PortalInter;

//给门户网站提供服务的控制类
@Controller
@RequestMapping(value = "portal")
public class PortalController {
    private static final Logger log = LoggerFactory.getLogger(PortalController.class);

	private PortalInter portalInter;
	
	//查询所有的分类以及其中一个分类下的所有资讯，并最终封装成一个CateInfoVO返回给界面
	@RequestMapping(value = "/query")
    public @ResponseBody CateInfoVO queryCacheData(HttpServletRequest request,@RequestParam("id") long id){

		CateInfoVO cateInfoVO = new CateInfoVO();
		try{
			log.info("queryCacheData start");
			
			cateInfoVO = portalInter.queryCateInfo(id);
			
			log.info("queryCacheData sucess");
		}catch(Exception e){
			log.error("queryCacheData error!", e);
		}
		return cateInfoVO;
	
	}
	

	@Resource(name = "portalImpl")
	public void setPortalInter(PortalInter portalInter) {
		this.portalInter = portalInter;
	}
	
}
