// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.gy.dao.inter;

import java.util.List;
import org.apache.ibatis.annotations.Param;

import com.gy.model.CateInfoRelation;
import com.gy.model.Category;

public interface CategoryMapper {
	
    int insert(@Param("category") Category category);
    
    List<Category> getCategorys();
    
    Category selectByID(@Param("id") Long id);
    
    int update(@Param("category")  Category category);
    
    int delete(@Param("id") Long id);
    
    int insertRelations(@Param("list")List<CateInfoRelation> relationList);
    
    int deleteRelationByCateid(@Param("cateid") Long cateid);
    
    List<CateInfoRelation> getRelationsByCateid(@Param("cateid") Long cateid);
    
    List<CateInfoRelation> getRelations();

}
