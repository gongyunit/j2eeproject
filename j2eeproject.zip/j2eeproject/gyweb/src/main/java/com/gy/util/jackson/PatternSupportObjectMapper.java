// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.gy.util.jackson;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;

import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.format.DateTimeFormatter;

//给jsonutil工具类提供的辅助类
public class PatternSupportObjectMapper extends ObjectMapper {

    public static final java.lang.String DATE_FORMAT_PATTERN = "yyyy-MM-dd'T'HH:mm:ss.S'Z'";

    public PatternSupportObjectMapper(String dateFormatPattern, DateTimeFormatter formatter) {
        super();
        JavaTimeModule module = new JavaTimeModule();
        if (formatter != null) {
            module.addSerializer(Instant.class, PatternSupportInstantSerializer.INSTANCE.withFormat(false, formatter));
            module.addDeserializer(Instant.class, PatternSupportInstantDeserializer.INSTANCE.withDateFormat(formatter));
        }
        this.registerModule(module);// support jsr310
        if (dateFormatPattern != null) {
            this.setDateFormat(new SimpleDateFormat(dateFormatPattern));
        }
        this.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        this.configure(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT, true);
        this.configure(DeserializationFeature.READ_UNKNOWN_ENUM_VALUES_AS_NULL, true);
        this.configure(SerializationFeature.WRITE_ENUMS_USING_INDEX, true);
        this.configure(DeserializationFeature.READ_ENUMS_USING_TO_STRING, false);
    }

    public PatternSupportObjectMapper() {
        this(null, null);
    }
}
