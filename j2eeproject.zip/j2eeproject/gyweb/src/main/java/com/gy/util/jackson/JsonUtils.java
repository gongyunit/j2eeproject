// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.gy.util.jackson;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.core.JsonEncoding;
import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.ByteArrayOutputStream;
import java.time.format.DateTimeFormatter;

//Json的工具类，用于将对象转换为json串，以及将json转换为对象
public class JsonUtils {

    private DateTimeFormatter dateTimeFormatter;
    private String dateFormatPattern;
    //值为true时，json里会保存类型信息
    private boolean typing;

    public static JsonUtils instance() {
        return new JsonUtils();
    }

    public static String encode(Object obj) {
        return JsonUtils.instance().doEncode(obj);
    }

    public static String lightEncode(Object obj) {
        return JsonUtils.instance().doEncode(obj, false);
    }

    public static <T> T decode(String content, Class<T> valueType) {
        return JsonUtils.instance().doDecode(content, valueType);
    }

    public static <T> T decode(String content, TypeReference typeReference) {
        return JsonUtils.instance().doDecode(content, typeReference);
    }

    public JsonUtils withDateFormatPattern(String dateFormatPattern) {
        this.dateFormatPattern = dateFormatPattern;
        return this;
    }

    public JsonUtils withDateTimeFormatter(DateTimeFormatter dateTimeFormatter) {
        this.dateTimeFormatter = dateTimeFormatter;
        return this;
    }

    public JsonUtils enableTyping() {
        this.typing = true;
        return this;
    }

    public String doEncode(Object obj) {
        return doEncode(obj, true);
    }

    public String doLightEncode(Object obj) {
        return doEncode(obj, false);
    }

    private String doEncode(Object obj, boolean includeNullProperty) {
        ObjectMapper om = new PatternSupportObjectMapper(dateFormatPattern, dateTimeFormatter);
        if (typing) {
            om.enableDefaultTyping(ObjectMapper.DefaultTyping.NON_FINAL);
        }
        if (!includeNullProperty) {
            om.setSerializationInclusion(JsonInclude.Include.NON_NULL);
        }
        try (ByteArrayOutputStream baos = new ByteArrayOutputStream()) {
            JsonGenerator generator = om.getFactory().createGenerator(baos, JsonEncoding.UTF8);
            generator.writeObject(obj);
            String result = new String(baos.toByteArray(), "utf-8");
            return result;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }


    public <T> T doDecode(String content, Class<T> valueType) {
        ObjectMapper om = new PatternSupportObjectMapper(dateFormatPattern, dateTimeFormatter);
        if (typing) {
            om.enableDefaultTyping(ObjectMapper.DefaultTyping.NON_FINAL);
        }
        try {
            return om.readValue(content, valueType);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public <T> T doDecode(String content, TypeReference typeReference) {
        ObjectMapper om = new PatternSupportObjectMapper(dateFormatPattern, dateTimeFormatter);
        if (typing) {
            om.enableDefaultTyping(ObjectMapper.DefaultTyping.NON_FINAL);
        }
        try {
            return om.readValue(content, typeReference);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    protected JsonUtils() {
        this(null, null);
    }

    protected JsonUtils(String dateFormatPattern, DateTimeFormatter formatter) {
        this.dateFormatPattern = dateFormatPattern;
        this.dateTimeFormatter = formatter;
    }
}
