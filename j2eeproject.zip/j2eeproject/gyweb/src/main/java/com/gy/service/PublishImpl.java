// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.gy.service;

import java.util.List;
import java.util.Set;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import com.gy.dao.cache.inter.ICategoryCacheDao;
import com.gy.dao.cache.inter.IInfoCacheDao;
import com.gy.model.CateInfoRelation;
import com.gy.model.Category;
import com.gy.model.Information;
import com.gy.service.inter.CategoryInter;
import com.gy.service.inter.InformationInter;
import com.gy.service.inter.PublishInter;

//数据发布的服务层类
public class PublishImpl implements PublishInter {
	
	private static Log log = LogFactory.getLog(PublishImpl.class);
	private ICategoryCacheDao categoryCacheDao;
	private IInfoCacheDao infoCacheDao;
	private CategoryInter categoryInter;
	private InformationInter informationInter;

	//从数据库中查询所有的分类和资讯，并将其同步到缓存中
	@Override
	public void publishAll() {
		
		List<Information> infos = informationInter.getInformations();
		List<Category> categorys = categoryInter.getCategoryns();
		List<CateInfoRelation> relstions = categoryInter.getRelations();
		
		infoCacheDao.deleteAll();
		categoryCacheDao.deleteAllRelations();
		categoryCacheDao.deleteAll();
		
		infoCacheDao.insertList(infos);
		categoryCacheDao.insertRelations(relstions);
		categoryCacheDao.insertList(categorys);
		
	}


	public ICategoryCacheDao getCategoryCacheDao() {
		return categoryCacheDao;
	}


	public void setCategoryCacheDao(ICategoryCacheDao categoryCacheDao) {
		this.categoryCacheDao = categoryCacheDao;
	}


	public IInfoCacheDao getInfoCacheDao() {
		return infoCacheDao;
	}


	public void setInfoCacheDao(IInfoCacheDao infoCacheDao) {
		this.infoCacheDao = infoCacheDao;
	}


	public CategoryInter getCategoryInter() {
		return categoryInter;
	}


	public void setCategoryInter(CategoryInter categoryInter) {
		this.categoryInter = categoryInter;
	}


	public InformationInter getInformationInter() {
		return informationInter;
	}


	public void setInformationInter(InformationInter informationInter) {
		this.informationInter = informationInter;
	}

}
