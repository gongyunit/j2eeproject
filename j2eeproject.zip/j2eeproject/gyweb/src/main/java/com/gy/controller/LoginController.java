// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.gy.controller;

import java.util.Map;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import com.gy.model.LoginVO;
import com.gy.model.RequestResult;
import com.gy.util.jackson.JsonUtils;
import com.gy.util.prop.PropertiesUtil;

//用户登录校验
@Controller
@RequestMapping(value = "login")
public class LoginController {
    private static final Logger log = LoggerFactory.getLogger(LoginController.class);

    @RequestMapping(value="/vf")
    public @ResponseBody RequestResult login(@RequestBody String userinfo){
        RequestResult result = new RequestResult();
        try{
            log.info("login start");

            //将界面传递的用户信息转换为对象
            LoginVO lv = (LoginVO)JsonUtils.decode(userinfo, LoginVO.class);

            //将配置文件配置的用户信息读取出来
            Map map = PropertiesUtil.parseProperties("/all.properties");
            String namep = (String) map.get("loginname");
            String pwdp = (String) map.get("loginpwd");
            
            //判断两者是否相等
            if(namep.equals(lv.getName())&&pwdp.equals(lv.getPwd())){
                result.setCode("0");
                result.setErrorMsg("");
                log.info("login sucess");
            }else{
                result.setCode("2");
                result.setErrorMsg("");
                log.info("login error");
            }

        }catch(Exception e){
            log.error("login error!", e);
            result.setCode("1");
            result.setErrorMsg("login error!!!");
        }
        return result;
    }
    


}