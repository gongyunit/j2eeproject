// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.gy.service;

import java.util.List;
import java.util.Set;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import com.gy.dao.cache.inter.ICategoryCacheDao;
import com.gy.dao.cache.inter.IInfoCacheDao;
import com.gy.model.CateInfoVO;
import com.gy.model.Category;
import com.gy.model.Information;
import com.gy.service.inter.PortalInter;

//给门户控制类提供服务的类
public class PortalImpl implements PortalInter {
	
	private static Log log = LogFactory.getLog(PortalImpl.class);
	private ICategoryCacheDao categoryCacheDao;
	private IInfoCacheDao infoCacheDao;

	//查询所有的分类以及其中一个分类下的所有资讯，并最终封装成一个CateInfoVO返回给控制层
	@Override
	public CateInfoVO queryCateInfo(Long cateid) {
		CateInfoVO cateInfoVO = new CateInfoVO();
		
		List<Category> categorys = categoryCacheDao.getCategorys();
		Set<Object> infoids;
		if(cateid==-1){
			infoids = categoryCacheDao.getRelationsByCateid(categorys.get(0).getId());
		}else{
			infoids = categoryCacheDao.getRelationsByCateid(cateid);
		}
		List<Information> infos = infoCacheDao.getInfosByIds(infoids);
		
		cateInfoVO.setCategoryList(categorys);
		cateInfoVO.setInfoList(infos);
		
		return cateInfoVO;
	}
	


	public ICategoryCacheDao getCategoryCacheDao() {
		return categoryCacheDao;
	}


	public void setCategoryCacheDao(ICategoryCacheDao categoryCacheDao) {
		this.categoryCacheDao = categoryCacheDao;
	}


	public IInfoCacheDao getInfoCacheDao() {
		return infoCacheDao;
	}


	public void setInfoCacheDao(IInfoCacheDao infoCacheDao) {
		this.infoCacheDao = infoCacheDao;
	}


}
