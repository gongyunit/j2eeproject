// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.gy.util.jackson;

import com.fasterxml.jackson.datatype.jsr310.ser.InstantSerializerBase;

import java.time.Instant;
import java.time.format.DateTimeFormatter;

//给jsonutil工具类提供的辅助类
public class PatternSupportInstantSerializer extends InstantSerializerBase<Instant> {

    public static final PatternSupportInstantSerializer INSTANCE = new PatternSupportInstantSerializer();
    private static final long serialVersionUID = 1L;

    protected PatternSupportInstantSerializer() {
        super(Instant.class, Instant::toEpochMilli, Instant::getEpochSecond, Instant::getNano, null);
    }

    public PatternSupportInstantSerializer(InstantSerializerBase<Instant> base, Boolean useTimestamp,
                                           DateTimeFormatter dtf) {
        super(base, useTimestamp, dtf);
    }

    @Override
    protected InstantSerializerBase withFormat(Boolean useTimestamp, DateTimeFormatter dtf) {
        return new PatternSupportInstantSerializer(this, useTimestamp, dtf);
    }
}
