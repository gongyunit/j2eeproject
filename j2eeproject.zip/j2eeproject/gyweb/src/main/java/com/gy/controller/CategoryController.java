// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.gy.controller;


import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.gy.model.CateInfoRelation;
import com.gy.model.CateInfoRelationVO;
import com.gy.model.Category;
import com.gy.model.CategoryVO;
import com.gy.model.RequestResult;
import com.gy.service.inter.CategoryInter;
import com.gy.util.jackson.JsonUtils;

//此类是分类以及分类资讯关系的控制类
@Controller
@RequestMapping(value = "category")
public class CategoryController {
    private static final Logger log = LoggerFactory.getLogger(CategoryController.class);

	private CategoryInter categoryInter;
	
	//获取所有的分类
	@RequestMapping(value="/getAll",  method=RequestMethod.POST)
	public @ResponseBody CategoryVO queryCategorys(){
		CategoryVO categoryVO = new CategoryVO();
		try{
			log.info("queryCategorys start");
			
			List<Category> categoryList = new ArrayList<Category>();
			categoryList = categoryInter.getCategoryns();
			
			categoryVO.setCategoryList(categoryList);
			
			log.info("queryCategorys sucess");
		}catch(Exception e){
			log.error("queryCategorys error!", e);
		}
		return categoryVO;
	}
	
	//增加一个分类
	@RequestMapping(value="/add",  method=RequestMethod.POST)
	public @ResponseBody RequestResult addCategory(@RequestBody String addinfo){
		RequestResult result = new RequestResult();
		try{
			log.info("insert start");
			
			Date date = Calendar.getInstance().getTime();
			Category category = new Category();
			category = (Category)JsonUtils.decode(addinfo, Category.class);
			category.setCreateTime(date);
			category.setModifyTime(date);
			
			categoryInter.insert(category);
			
			log.info("insert sucess");
			result.setCode("0");
			result.setErrorMsg("");
		}catch(Exception e){
			log.error("insert error!", e);
			result.setCode("1");
			result.setErrorMsg("insert error!");
		}
		return result;
	}
	
	//修改一个分类
	@RequestMapping(value = "/modify",  method=RequestMethod.POST)
    public @ResponseBody RequestResult modifyCategory(@RequestBody String mdinfo){
		RequestResult result = new RequestResult();
		try{
			log.info("modifyCategory start");
			
			
			Date date = Calendar.getInstance().getTime();
			Category category = new Category();
			category = (Category)JsonUtils.decode(mdinfo, Category.class);
			category.setModifyTime(date);
			
			categoryInter.update(category);
			
			log.info("modifyCategory sucess");
			result.setCode("0");
			result.setErrorMsg("");
		}catch(Exception e){
			log.error("modifyCategory error!", e);
			result.setCode("1");
			result.setErrorMsg("modifyCategory error!");
		}
		return result;
    	
    }
	
	//按照分类id查询分类
	@RequestMapping(value = "/select")
    public @ResponseBody Category selectCategory(HttpServletRequest request,@RequestParam("id") long id){
		Category category = null;
		try{
			log.info("selectCategory start");
			
			category = categoryInter.selectByID(id);
			
			log.info("selectCategory sucess");
		}catch(Exception e){
			log.error("selectCategory error!", e);
		}
		return category;
    	
    }
	
	//按照分类id删除单个分类
	@RequestMapping(value = "/delete")
    public @ResponseBody RequestResult deleteCategory(HttpServletRequest request,@RequestParam("id") long id){
		
		
		RequestResult result = new RequestResult();
		try{
			log.info("deleteCategory start");
			
			categoryInter.delete(id);
			
			log.info("deleteCategory sucess");
			result.setCode("0");
			result.setErrorMsg("");
		}catch(Exception e){
			log.error("deleteCategory error!", e);
			result.setCode("1");
			result.setErrorMsg("deleteCategory error!");
		}
		return result;
    	
    }	
	
	//批量增加分类资讯的关系
	@RequestMapping(value="/addRelation",  method=RequestMethod.POST)
	public @ResponseBody RequestResult addRelation(@RequestBody String relations){
		RequestResult result = new RequestResult();
		try{
			log.info("addRelation start");
			
			CateInfoRelationVO cateInfoRelationVO = new CateInfoRelationVO();
			cateInfoRelationVO = (CateInfoRelationVO)JsonUtils.decode(relations, CateInfoRelationVO.class);
			
			categoryInter.deleteRelationByCateid(cateInfoRelationVO.getCateInfoRelationList().get(0).getCateid());
			
			List<CateInfoRelation> cateInfoRelationList = cateInfoRelationVO.getCateInfoRelationList();
			Date date = Calendar.getInstance().getTime();
			
			for(CateInfoRelation one :cateInfoRelationList){
				one.setCreateTime(date);
				one.setModifyTime(date);
			}
			categoryInter.insertRelations(cateInfoRelationList);
			
			log.info("addRelation sucess");
			result.setCode("0");
			result.setErrorMsg("");
		}catch(Exception e){
			log.error("addRelation error!", e);
			result.setCode("1");
			result.setErrorMsg("addRelation error!");
		}
		return result;
	}
	
	
	//将分类的服务层bean通过@Resource注解，注入到本类中
	@Resource(name = "categoryImpl")
	public void setCategoryInter(CategoryInter categoryInter) {
		this.categoryInter = categoryInter;
	}
	
}
