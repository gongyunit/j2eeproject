// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.gy.controller;

import javax.annotation.Resource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import com.gy.model.RequestResult;
import com.gy.service.inter.PublishInter;
//处理数据发布至缓存的控制类
@Controller
@RequestMapping(value = "publish")
public class PublishController {
    private static final Logger log = LoggerFactory.getLogger(PublishController.class);

	private PublishInter publishInter;
	
	//从数据库中查询所有的分类和资讯，并将其同步到缓存中
	@RequestMapping(value="/puball",  method=RequestMethod.POST)
	public @ResponseBody RequestResult publishAll(){
		RequestResult result = new RequestResult();
		try{
			log.info("publishAll start");
			
			publishInter.publishAll();
			
			log.info("publishAll sucess");
			result.setCode("0");
			result.setErrorMsg("");
		}catch(Exception e){
			log.error("publishAll error!", e);
			result.setCode("1");
			result.setErrorMsg("publishAll error!");
		}
		return result;
	}
	

	@Resource(name = "publishImpl")
	public void setPublishInter(PublishInter publishInter) {
		this.publishInter = publishInter;
	}
	
}
