// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.gy.service;

import java.util.List;

import com.gy.dao.inter.CategoryMapper;
import com.gy.model.CateInfoRelation;
import com.gy.model.Category;
import com.gy.service.inter.CategoryInter;

//处理分类以及分类和资讯关系的服务层类
public class CategoryImpl implements CategoryInter {
	
	private CategoryMapper categoryMapper;

	public CategoryMapper getCategoryMapper() {
		return categoryMapper;
	}

	public void setCategoryMapper(CategoryMapper categoryMapper) {
		this.categoryMapper = categoryMapper;
	}

	//调用数据库访问层的类，插入一个分类
	@Override
	public int insert(Category category) {
		return categoryMapper.insert(category);
	}

	//调用数据库访问层的类，查询所有分类，
	@Override
	public List<Category> getCategoryns() {
		return categoryMapper.getCategorys();
	}

	//调用数据库访问层的类，根据id查询分类
	@Override
	public Category selectByID(Long id) {
		return categoryMapper.selectByID(id);
	}

	//调用数据库访问层的类，更新分类
	@Override
	public int update(Category category) {
		return categoryMapper.update(category);
	}

	//调用数据库访问层的类，删除一个分类
	@Override
	public int delete(Long id) {
		return categoryMapper.delete(id);
	}

	//调用数据库访问层的类，批量插入分类和资讯的关系
	@Override
	public int insertRelations(List<CateInfoRelation> relationList) {
		return categoryMapper.insertRelations(relationList);
	}

	//调用数据库访问层的类，根据分类id，查询该分类下的分类资讯关系集合
	@Override
	public List<CateInfoRelation> getRelationsByCateid(Long cateid) {
		return categoryMapper.getRelationsByCateid(cateid);
	}

	//调用数据库访问层的类，根据分类id删除分类资讯关系
	@Override
	public int deleteRelationByCateid(Long cateid) {
		return categoryMapper.deleteRelationByCateid(cateid);
	}

	//调用数据库访问层的类，查询所有关系
	@Override
	public List<CateInfoRelation> getRelations() {
		return categoryMapper.getRelations();
	}

	
}
