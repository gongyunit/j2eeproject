// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.gy.dao.cache.inter;

import java.util.List;
import java.util.Set;
import com.gy.model.Information;

public interface IInfoCacheDao {
	
	 //从缓存中，批量插入资讯
	void insertList(List<Information> informationList);

	 //从缓存中，批量删除资讯
	void deleteAll();

	 //从缓存中，根据资讯的id集合，批量查询指定的资讯集合
	List<Information> getInfosByIds(Set<Object> ids);
    
}
