// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.gy.dao.cache.inter;

import java.util.List;
import java.util.Set;

import com.gy.model.CateInfoRelation;
import com.gy.model.Category;

//处理分类缓存的数据访问层接口
public interface ICategoryCacheDao {
	
    //从缓存中，批量插入分类
    void insertList(List<Category> categoryList);
    
    //从缓存中，通过模糊匹配的方式，批量删除所有的分类
    void deleteAll();
    
	//从缓存中，获取所有的分类
    List<Category> getCategorys();
    
	//从缓存中，批量插入分类和资讯的关系
    void insertRelations(List<CateInfoRelation> relationList);
     
	//从缓存中，删除所有的分类和资讯关系
    void deleteAllRelations();
    
	//根据分类id，查询该分类下的所有资讯id的集合
    Set<Object> getRelationsByCateid(Long cateid);

}
