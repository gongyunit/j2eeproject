// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.gy.dao.cache;

import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.data.redis.core.HashOperations;
import org.springframework.data.redis.core.RedisTemplate;

import com.gy.dao.cache.inter.IInfoCacheDao;
import com.gy.model.Information;
import com.gy.util.obj2json.CacheUtil;

//处理资讯缓存的数据访问层类
public class InfoCacheDaoImpl implements IInfoCacheDao {
	
	private RedisTemplate<String,Object> redisTemplate;  
	private final static String infoKeyStart = "infoRoot:info";
	
	//将spring提供的redistemplate设置到本类中
	public void setRedisTemplate(RedisTemplate<String, Object> redisTemplate)  
	 {  
	      this.redisTemplate = redisTemplate;  
	}

	 //从缓存中，批量插入资讯
	@Override
	public void insertList(List<Information> informationList) {
		for(Information information:informationList){
    		Map<String, String> informationmap =CacheUtil.convertObject2Map(information);
    		HashOperations<String, Object, Object>  informationhash = redisTemplate.opsForHash();
    		informationhash.putAll(infoKeyStart+information.getId(), informationmap);
    	}
	}

	 //从缓存中，批量删除资讯
	@Override
	public void deleteAll() {
		redisTemplate.delete(redisTemplate.keys(infoKeyStart+"*"));
	}

	 //从缓存中，根据资讯的id集合，批量查询指定的资讯集合
	@Override
	public List<Information> getInfosByIds(Set<Object> ids) {
		HashOperations<String, Object, Object>  informationhash = redisTemplate.opsForHash();
		List<Information> infoList = new LinkedList<Information>();
		
		for(Object id :ids){
			Map<Object, Object> informationmap = informationhash.entries(infoKeyStart+id.toString());
			Information info = CacheUtil.convertMap2Object(informationmap, Information.class);
			infoList.add(info);
		}
		return infoList;
	}
	
}
