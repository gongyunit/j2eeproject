// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.gy.service.inter;

import com.gy.model.CateInfoVO;

//给门户控制类提供服务的接口类
public interface PortalInter {
	
	//查询所有的分类以及其中一个分类下的所有资讯，并最终封装成一个CateInfoVO返回给控制层
	CateInfoVO queryCateInfo(Long cateid);
    
}
