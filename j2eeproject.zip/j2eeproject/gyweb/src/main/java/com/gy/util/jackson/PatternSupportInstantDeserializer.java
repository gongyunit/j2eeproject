// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.gy.util.jackson;

import com.fasterxml.jackson.databind.JsonDeserializer;
import com.fasterxml.jackson.datatype.jsr310.deser.InstantDeserializer;

import java.time.Instant;
import java.time.format.DateTimeFormatter;

//给jsonutil工具类提供的辅助类
public class PatternSupportInstantDeserializer extends InstantDeserializer<Instant> {

    public static final PatternSupportInstantDeserializer INSTANCE = new PatternSupportInstantDeserializer
            (InstantDeserializer.INSTANT, DateTimeFormatter.ISO_INSTANT);

    protected PatternSupportInstantDeserializer(InstantDeserializer<Instant> base, DateTimeFormatter f) {
        super(base, f);
    }

    @Override
    public JsonDeserializer<Instant> withDateFormat(DateTimeFormatter dtf) {
        return super.withDateFormat(dtf);
    }

}
