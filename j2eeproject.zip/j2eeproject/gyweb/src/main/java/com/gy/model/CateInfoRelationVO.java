// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.gy.model;

import java.util.LinkedList;
import java.util.List;

//基于分类和资讯关系的集合封装的实体类
public class CateInfoRelationVO {

	private List<CateInfoRelation> cateInfoRelationList = new LinkedList<CateInfoRelation>();

	public List<CateInfoRelation> getCateInfoRelationList() {
		return cateInfoRelationList;
	}

	public void setCateInfoRelationList(List<CateInfoRelation> cateInfoRelationList) {
		this.cateInfoRelationList = cateInfoRelationList;
	}

	
}
