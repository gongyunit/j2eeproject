// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.gy.model;

import java.util.LinkedList;
import java.util.List;

//基于分类集合封装的实体类
public class CategoryVO {

	private List<Category> categoryList = new LinkedList<Category>();

	public List<Category> getCategoryList() {
		return categoryList;
	}

	public void setCategoryList(List<Category> categoryList) {
		this.categoryList = categoryList;
	}

	
}
