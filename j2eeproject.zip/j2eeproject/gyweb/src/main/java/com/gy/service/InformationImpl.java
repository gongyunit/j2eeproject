// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.gy.service;

import java.util.List;
import com.gy.dao.inter.InformationMapper;
import com.gy.model.Information;
import com.gy.service.inter.InformationInter;

//处理资讯的服务层类
public class InformationImpl implements InformationInter {
	
	private InformationMapper informationMapper;

	//插入一个资讯
	@Override
	public int insert(Information information) {
		return informationMapper.insert(information);
	}

	//获取所有资讯
	@Override
	public List<Information> getInformations() {
		List<Information> infoList = informationMapper.getInformations();
		return infoList;
	}
	
	//根据id查询一个资讯
	@Override
	public Information selectByID(Long id) {
		return informationMapper.selectByID(id);
	}

	//更新资讯
	@Override
	public int update(Information information) {
		return informationMapper.update(information);
	}

	//删除一个分类
	@Override
	public int delete(Long id) {
		return informationMapper.delete(id);
	}

	public InformationMapper getInformationMapper() {
		return informationMapper;
	}

	public void setInformationMapper(InformationMapper informationMapper) {
		this.informationMapper = informationMapper;
	}
	
}
