// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.gy.service.inter;

import java.util.List;


import com.gy.model.Information;

//处理资讯的服务层接口类
public interface InformationInter {
	
	//插入一个资讯
	int insert(Information information);
    
	//获取所有资讯
	List<Information> getInformations();
    
	//根据id查询一个资讯
	Information selectByID(Long id);
    
	//更新资讯
	int update( Information information);
    
	//删除一个分类
	int delete( Long id);
    
}
