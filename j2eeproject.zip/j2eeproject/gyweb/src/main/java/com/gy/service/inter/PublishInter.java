// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.gy.service.inter;

//数据发布的服务层接口类
public interface PublishInter {
	
	//从数据库中查询所有的分类和资讯，并将其同步到缓存中
	void publishAll();
    
}
