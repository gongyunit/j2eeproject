// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.gy.model;

import java.io.Serializable;
import java.util.Date;

//分类和资讯的关系实体类
public class CateInfoRelation implements Serializable{

	private static final long serialVersionUID = -1430401305363788445L;
	
	private long id;
	
	private long cateid;
	
	private long infoid;
	
	private Date createTime;
	
	private Date modifyTime;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}


	public long getInfoid() {
		return infoid;
	}

	public void setInfoid(long infoid) {
		this.infoid = infoid;
	}

	public long getCateid() {
		return cateid;
	}

	public void setCateid(long cateid) {
		this.cateid = cateid;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public Date getModifyTime() {
		return modifyTime;
	}

	public void setModifyTime(Date modifyTime) {
		this.modifyTime = modifyTime;
	}

}
