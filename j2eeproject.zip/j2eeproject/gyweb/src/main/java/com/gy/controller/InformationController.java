// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.gy.controller;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.gy.model.CateInfoRelation;
import com.gy.model.Information;
import com.gy.model.InformationVO;
import com.gy.model.RequestResult;
import com.gy.service.inter.CategoryInter;
import com.gy.service.inter.InformationInter;
import com.gy.util.jackson.JsonUtils;

//处理资讯的控制类
@Controller
@RequestMapping(value = "info")
public class InformationController {
    private static final Logger log = LoggerFactory.getLogger(InformationController.class);

	private InformationInter informationInter;
	private CategoryInter categoryInter;

	//获取所有的资讯
	@RequestMapping(value="/getAll",  method=RequestMethod.POST)
	public @ResponseBody InformationVO queryInfos(){
		InformationVO infoVO = new InformationVO();
		try{
			log.info("queryInfos start");
			
			List<Information> infoList = new ArrayList<Information>();
			infoList = informationInter.getInformations();
			
			infoVO.setInfoList(infoList);
			
			log.info("queryInfos sucess");
		}catch(Exception e){
			log.error("queryInfos error!", e);
		}
		return infoVO;
	}
	
	//根据分类id获取分类列表，并封装成InformationVO返回到界面
	@RequestMapping(value = "/getByCateid")
    public @ResponseBody InformationVO getInfosByCateid(HttpServletRequest request,@RequestParam("id") long id){

		InformationVO infoVO = new InformationVO();
		try{
			log.info("getInfosByCateid start");
			
			List<Information> infoList = new ArrayList<Information>();
			infoList = informationInter.getInformations();
			
			List<CateInfoRelation> relations = categoryInter.getRelationsByCateid(id);
			
			for(Information one:infoList){
				
				for(CateInfoRelation relation:relations){
					if(one.getId() == relation.getInfoid()){
						one.setIsRelateCategory(1);
					}
				}
				
			}
			
			infoVO.setInfoList(infoList);
			
			log.info("getInfosByCateid sucess");
		}catch(Exception e){
			log.error("getInfosByCateid error!", e);
		}
		return infoVO;
	
	}
	
	//增加一个资讯
	@RequestMapping(value="/add",  method=RequestMethod.POST)
	public @ResponseBody RequestResult addInformation(@RequestBody String addinfo){
		RequestResult result = new RequestResult();
		try{
			log.info("insert start");
			
			Date date = Calendar.getInstance().getTime();
			Information info = new Information();
			info = (Information)JsonUtils.decode(addinfo, Information.class);
			info.setCreateTime(date);
			info.setModifyTime(date);
			
			informationInter.insert(info);
			
			log.info("insert sucess");
			result.setCode("0");
			result.setErrorMsg("");
		}catch(Exception e){
			log.error("insert error!", e);
			result.setCode("1");
			result.setErrorMsg("insert error!");
		}
		return result;
	}
	
	//修改一个资讯
	@RequestMapping(value = "/modify",  method=RequestMethod.POST)
    public @ResponseBody RequestResult modifyInformation(@RequestBody String mdinfo){
		RequestResult result = new RequestResult();
		try{
			log.info("modifyInformation start");
			
			
			Date date = Calendar.getInstance().getTime();
			Information info = new Information();
			info = (Information)JsonUtils.decode(mdinfo, Information.class);
			info.setModifyTime(date);
			
			informationInter.update(info);
			
			log.info("modifyInformation sucess");
			result.setCode("0");
			result.setErrorMsg("");
		}catch(Exception e){
			log.error("modifyInformation error!", e);
			result.setCode("1");
			result.setErrorMsg("modifyInformation error!");
		}
		return result;
    	
    }
	
	//按照资讯id查询
	@RequestMapping(value = "/select")
    public @ResponseBody Information selectInformation(HttpServletRequest request,@RequestParam("id") long id){
		Information info = null;
		try{
			log.info("selectInformation start");
			
			info = informationInter.selectByID(id);
			
			log.info("selectInformation sucess");
		}catch(Exception e){
			log.error("selectInformation error!", e);
		}
		return info;
    	
    }
	
	//根据资讯id删除
	@RequestMapping(value = "/delete")
    public @ResponseBody RequestResult deleteInformation(HttpServletRequest request,@RequestParam("id") long id){
		
		
		RequestResult result = new RequestResult();
		try{
			log.info("deleteInformation start");
			
			informationInter.delete(id);
			
			log.info("deleteInformation sucess");
			result.setCode("0");
			result.setErrorMsg("");
		}catch(Exception e){
			log.error("deleteInformation error!", e);
			result.setCode("1");
			result.setErrorMsg("deleteInformation error!");
		}
		return result;
    	
    }	
	
	//通过注解@Resource将资讯的服务bean注入进来
	@Resource(name = "informationImpl")
	public void setInformationInter(InformationInter informationInter) {
		this.informationInter = informationInter;
	}
	
	//通过注解@Resource将分类的服务bean注入进来
	@Resource(name = "categoryImpl")
	public void setCategoryInter(CategoryInter categoryInter) {
		this.categoryInter = categoryInter;
	}
	
}
