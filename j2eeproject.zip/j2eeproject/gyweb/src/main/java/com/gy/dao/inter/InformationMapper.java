// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.gy.dao.inter;

import java.util.List;

import org.apache.ibatis.annotations.Param;
import com.gy.model.Information;

public interface InformationMapper {
	
    int insert(@Param("information") Information information);
    
    List<Information> getInformations();
    
    Information selectByID(@Param("id") Long id);
    
    int update(@Param("information")  Information information);
    
    int delete(@Param("id") Long id);


}
