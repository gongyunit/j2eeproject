// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.gy.util.prop;

import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Properties;

public class PropertiesUtil {

	public  static Map<String, String> parseProperties(String filePaht) {
		
		InputStream in = null;
		Map<String, String> contentMap = new HashMap<String, String>();
		
		try {
			// 读取属性文件a.properties
			in = PropertiesUtil.class.getResourceAsStream(filePaht);
			/// 加载属性列表
			Properties prop = new Properties();
			prop.load(in);
			
			Iterator<String> it = prop.stringPropertyNames().iterator();
			while (it.hasNext()) {
				String key = it.next();
				String value = prop.getProperty(key);
				contentMap.put(key, value);
			}

		} catch (Exception e) {
			 throw new RuntimeException("read file error:" + filePaht, e);
		} finally {
			if (in != null) {
				try {
					in.close();
				} catch (IOException e) {
					throw new RuntimeException(" file close error:" + filePaht, e);
				}
			}

		}
		return contentMap;
	}
	
	
}
