// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.gy.model;

import java.io.Serializable;
import java.util.Date;

//资讯的实体类
public class Information implements Serializable{

	private static final long serialVersionUID = 6223933370013576609L;
	
	private long id;
	
	private String title;
	
	private String author;
	
	private String content;
	
	private Date createTime;
	
	private Date modifyTime;
	
	private int isRelateCategory = 0;//0:没有被选中；1：被选中

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public Date getModifyTime() {
		return modifyTime;
	}

	public void setModifyTime(Date modifyTime) {
		this.modifyTime = modifyTime;
	}

	public int getIsRelateCategory() {
		return isRelateCategory;
	}

	public void setIsRelateCategory(int isRelateCategory) {
		this.isRelateCategory = isRelateCategory;
	}
	
}
