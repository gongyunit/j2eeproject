// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.gy.util.obj2json;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import java.beans.IntrospectionException;
import java.beans.PropertyDescriptor;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.*;

//给缓存工具类提供的辅助类
public class ReflectionUtil {
    private static Log log = LogFactory.getLog(ReflectionUtil.class);
    private static String OBJID = "id";
    private static List<String> basicTypeList = new ArrayList(Arrays.asList("java.lang.Integer", "java.lang.Long", "java.lang.String",
            "java.lang.Double", "java.lang.Short", "java.lang.Byte", "java.lang.Float","java.util.Date","java.lang.Boolean","java.time.Instant",
            "int", "long", "double", "short", "byte", "float"));
    private static List<String> setTypeList = new ArrayList(Arrays.asList("java.util.Set", "java.util.List", "java.util.HashSet", "java.util.ArrayList"));
    private static List<String> mapTypeList = new ArrayList(Arrays.asList("java.util.Map", "java.util.HashMap"));
    private static String DATETYPE = "java.util.Date";

    private ReflectionUtil() {
        throw new IllegalAccessError("Utility class");
    }

    public static Object ensureObjAndIdNotNull(Object obj) {
        if(obj == null)    return null;
        Object objId = null;
        try {
            objId = getObjID(obj);
        } catch (Exception e1) {
            log.error("The obj may not hava \"id\" property. Can not get the obj ID. Obj:　" + obj.getClass().getName(), e1);
            return objId;
        }
        if(objId == null){
            log.warn("The value of this obj is null!");
        }
        return objId;
    }

    private static Object getObjID(Object obj) throws IntrospectionException, IllegalAccessException, IllegalArgumentException, InvocationTargetException {
        PropertyDescriptor pd = new PropertyDescriptor(OBJID, obj.getClass());
        Method readMethod = pd.getReadMethod();
        return readMethod.invoke(obj);
    }

    public static Field[] concat(Field[] first, Field[] second) {
        Field[] resultField= new Field[first.length+second.length];
        System.arraycopy(first, 0, resultField, 0, first.length);
        System.arraycopy(second, 0, resultField, first.length, second.length);
        return resultField;
    }

    public static Field[] findAllFields(Object obj) {
        Field[] allFields = obj.getClass().getDeclaredFields();
        allFields = findParentFieldFromObj(obj.getClass(), allFields);
        return allFields;
    }

    public static Field[] findParentFieldFromObj(Class<?> targetClass, Field[] oldField){
        Class<?> superClass = targetClass.getSuperclass();
        Field[] resultField = oldField;
        if(superClass == Object.class){
            return resultField;
        }
        Field[] superFields = superClass.getDeclaredFields();
        resultField = ReflectionUtil.concat(resultField, superFields);
        resultField = findParentFieldFromObj(superClass, resultField);
        return resultField;
    }

    public static String filterPackageName(String objType) {
        String[] names = objType.split("\\.");
        return names[names.length - 1];
    }
    public static Method getDeclaredMethod(Object object, String methodName, Class<?> ... parameterTypes){
        Method method = null ;
        for(Class<?> clazz = object.getClass() ; clazz != Object.class ; clazz = clazz.getSuperclass()) {
            try {
                method = clazz.getDeclaredMethod(methodName, parameterTypes) ;
                return method ;
            } catch (Exception e) {
                //这里甚么都不要做！并且这里的异常必须这样写，不能抛出去。
                //如果这里的异常打印或者往外抛，则就不会执行clazz = clazz.getSuperclass(),最后就不会进入到父类中了

            }
        }
        return null;
    }

    public static Object invokeMethod(Object object, String methodName,Class<?>[] parameterTypes, Object[] parameters)throws IllegalAccessException, IllegalArgumentException,InvocationTargetException {
        // 根据 对象、方法名和对应的方法参数 通过反射 调用上面的方法获取 Method 对象
        Method method = getDeclaredMethod(object, methodName, parameterTypes);
        if (null != method) {
            method.setAccessible(true);
            // 调用object 的 method 所代表的方法，其方法的参数是 parameters
            return method.invoke(object, parameters);
        }

        return null;
    }

    public static boolean isBasicType(Field field) {
        if(field.getType().isEnum())    return true;
        return basicTypeList.contains(field.getType().getName());
    }

    public static boolean isListOrSetType(Field field) {
        return setTypeList.contains(field.getType().getName());
    }

    public static boolean isMapType(Field field) {
        return mapTypeList.contains(field.getType().getName());
    }

    public static boolean isStatic(Field field) {
        return Modifier.isStatic(field.getModifiers());
    }

    public static boolean isDatepType(Field field) {
        return DATETYPE.equals(field.getType().getName());
    }

    public static void clearAllField(Object obj) {
        Class objClass = obj.getClass();
        Method[] objmethods = objClass.getDeclaredMethods();
        Map objMeMap = new HashMap();
        for (int i = 0; i < objmethods.length; i++) {
            Method method = objmethods[i];
            objMeMap.put(method.getName(), method);
        }
        for (int i = 0; i < objmethods.length; i++) {
            {
                String methodName = objmethods[i].getName();
                if (methodName != null && methodName.startsWith("get")) {
                    try {
                        Object returnObj = objmethods[i].invoke(obj, new Object[0]);
                        Method setmethod = (Method) objMeMap.get("set" + methodName.split("get")[1]);
                        if (returnObj != null)    returnObj = null;
                        setmethod.invoke(obj, returnObj);
                    } catch (Exception e) {
                        log.error("Clear obj error objName: " + obj.getClass().getName(), e);
                    }
                }
            }
        }
    }
}
