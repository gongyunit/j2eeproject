// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.gy.util.obj2json;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import com.gy.util.jackson.JsonUtils;
import java.lang.reflect.Field;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

//给缓存处理的辅助工具类：目的是将对象通过反射转换为map对象
public class CacheUtil {
    private static String IDPROPERTY = "id";
    private static String SIMPLEDATEFORMAT = "yyyy-MM-dd HH:mm:ss";
    private static Log log = LogFactory.getLog(CacheUtil.class);

    private CacheUtil() {
        throw new IllegalAccessError("Utility class");
    }

    public static  String  getCacheKeyfromObject(Object object, String className, String methodName){
        try {
            Object id =  ReflectionUtil.invokeMethod(object,methodName , null, null);
            if(null!=id){
                return className+id;
            }
        }catch (Exception e) {
            log.error("get obj key fail  This obj whill be give up!", e);
        }
        return null;
    }
    public  static Map<String, String> convertObject2Map(Object obj) {
        Map<String, String> mapValue = new HashMap<String, String>();
        try{
            Field[] fields = ReflectionUtil.findAllFields(obj);
            for(Field field : fields){
                if(needToDeal(field)){
                    field.setAccessible(true);
                    Object val = field.get(obj);
                    if(val==null || val.toString().isEmpty()){
                        if(IDPROPERTY.equals(field.getName())){
                            log.warn("The obj does not have a id. Give up cache it!!!");
                            break;
                        }
                    }else{
                        if(val instanceof Date){
                            val = convertDate2Timestamp(obj, field, val);
                        }
                        mapValue.put(field.getName(), val.toString());
                    }
                }
            }

        }catch(Exception e){
            log.error("Convert to object to map error!",e);
        }
        return mapValue;
    }

    private static boolean needToDeal(Field field) {
        return ReflectionUtil.isBasicType(field) && !ReflectionUtil.isStatic(field);
    }

    public static <T> T  convertMap2Object(Map<Object, Object> map, Class<T> type) {
        String jsonStr = JsonUtils.encode(map);
        return JsonUtils.decode(jsonStr,type);
    }

    public static Object convertDate2Timestamp(Object obj, Field field, Object val) throws IllegalAccessException {
        Date date = (Date) field.get(obj);
        DateFormat dateFormat = new SimpleDateFormat(SIMPLEDATEFORMAT);
        try {
            String dateStr = dateFormat.format(date);
            val = Timestamp.valueOf(dateStr).getTime();
        } catch (Exception e) {
            log.error("Convert to timestamp error! Field: " + field.getName() + " Value: " + field.get(obj), e);
        }
        return val;
    }

}
