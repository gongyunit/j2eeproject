CREATE DATABASE IF NOT EXISTS newgy default character set utf8 COLLATE utf8_general_ci;

use newgy;

drop table if exists category;

drop table if exists cateInfoRelation;

drop table if exists information;

CREATE TABLE `category` (
  `id`         					INT(10)   NOT NULL   AUTO_INCREMENT  ,
  `name`     		    VARCHAR(50)   ,
  `createTime`			DATETIME 	,
  `modifyTime`			DATETIME 	,
	PRIMARY KEY (`id`)
);

CREATE TABLE `cateInfoRelation` (
  `id`         				    	INT(10)   NOT NULL   AUTO_INCREMENT  ,
  `cateid`         					INT(10) ,
  `infoid`         					INT(10) ,
  `createTime`			DATETIME 	,
  `modifyTime`			DATETIME 	,
	PRIMARY KEY (`id`)
);

CREATE TABLE `information` (
  `id`         					INT(10)   NOT NULL   AUTO_INCREMENT  ,
  `title`     		        VARCHAR(100)   ,
  `author`     		      VARCHAR(20)   ,
  `content`     		    VARCHAR(1000)   ,
  `createTime`			DATETIME 	,
  `modifyTime`			DATETIME 	,
	PRIMARY KEY (`id`)
);